package com.mycompany.c45project;

import java.util.*;
import javax.swing.SwingUtilities; // Importar SwingUtilities

public class C45Project {

    public static void main(String[] args) {
        SQLLoader loader = new SQLLoader();

        // Configuración para el escenario de VIH
        String tabla = "V_ANALISIS_PROGRESION_VIH"; // Nombre de tu VISTA en SQL Server
        String clase = "progresion_enfermedad_evaluada"; // Columna objetivo

        System.out.println("🔄 Cargando datos desde la tabla: " + tabla + " para predecir '" + clase + "'...");
        List<Map<String, String>> datos = loader.cargarDatos(tabla);
        
        if (datos == null || datos.isEmpty()) { // Verificar también si datos es null
            System.out.println("❌ No se cargaron datos o la lista está vacía. Verifica la tabla/vista y la conexión.");
            return;
        }
        System.out.println("✅ Datos cargados: " + datos.size() + " registros.");

        // Lista de columnas que NO deben ser consideradas como atributos predictores directos
        // Estas son columnas de ID, fechas crudas, o cualquier otra que no sea una característica numérica o categórica codificada.
        List<String> columnasAIgnorarComoAtributos = Arrays.asList(
                "id_paciente",          // ID de paciente
                "id_seguimiento_vih",   // ID de seguimiento
                "fecha_seguimiento"     // Fecha cruda, ya usamos 'TiempoDesdeDiagnosticoMeses' y 'EdadAlSeguimiento'
                // Añade aquí otras columnas de tu VISTA que no sean predictoras directas
        );

        System.out.println("🔄 Obteniendo atributos (ignorando: " + columnasAIgnorarComoAtributos + ")...");
        List<String> atributos = loader.obtenerAtributos(tabla, clase, columnasAIgnorarComoAtributos);
        
        if (atributos == null || atributos.isEmpty()) { // Verificar también si atributos es null
            System.out.println("❌ No se obtuvieron atributos. Verifica la tabla/vista, la columna clase y las columnas a ignorar.");
            return;
        }
        System.out.println("✅ Atributos para el árbol: " + atributos);


        C45DecisionTree arbol = new C45DecisionTree();
        System.out.println("🧠 Entrenando el árbol de decisión C45...");
        arbol.train(datos, atributos, clase);
        System.out.println("🌳 Árbol entrenado.");

        System.out.println("\n🌲 Estructura del Árbol Generado (Consola):");
        arbol.printTree();

        // Guardar la raíz del árbol en una variable final para usarla en la lambda
        final TreeNode rootNodeParaVisualizar = arbol.getRoot(); 

        // Mostrar ventana gráfica del árbol usando el Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    System.out.println("\n🎨 Preparando visualización gráfica del árbol...");
                    if (rootNodeParaVisualizar != null) {
                        TreeVisualizer.mostrar(rootNodeParaVisualizar);
                        System.out.println("✅ Ventana del árbol de decisión debería estar visible.");
                    } else {
                        System.out.println("⚠️ El árbol está vacío (root es null), no se puede visualizar.");
                    }
                } catch (Exception e) {
                    // Capturar y mostrar cualquier error que ocurra al intentar mostrar la GUI
                    System.err.println("⚠️ Error crítico al mostrar la ventana gráfica del árbol:");
                    e.printStackTrace(); // Esto imprimirá la traza completa del error
                }
            }
        });
        
        // La predicción se ejecutará después de que la tarea de la GUI se haya puesto en cola.
        System.out.println("\n🔍 Realizando una predicción de ejemplo (esto puede aparecer en consola antes o durante la visualización de la ventana)...");
        Map<String, String> nuevoPacienteVIH = new HashMap<>();
        // Asegúrate de que estos atributos estén en la lista 'atributos' y que sus valores sean strings
        // que representen números (ya que C45DecisionTree usa Double.parseDouble).
        nuevoPacienteVIH.put("EdadAlSeguimiento", "45"); 
        nuevoPacienteVIH.put("SexoCodificado", "0"); 
        nuevoPacienteVIH.put("TiempoDesdeDiagnosticoMeses", "60");
        nuevoPacienteVIH.put("ConteoCD4Inicial", "250");
        nuevoPacienteVIH.put("CargaViralInicial", "100000");
        nuevoPacienteVIH.put("ConteoCD4Actual", "350");
        nuevoPacienteVIH.put("CargaViralActual", "5000"); 
        nuevoPacienteVIH.put("AdherenciaTratamientoTARVCodificada", "1"); 
        nuevoPacienteVIH.put("PresenciaCoinfeccionesCodificada", "0");
        // Añade más atributos si tu árbol los usa y son relevantes para la predicción

        System.out.println("  Datos del nuevo paciente para predicción: " + nuevoPacienteVIH);
        String resultadoPrediccion = arbol.predict(nuevoPacienteVIH); // arbol.predict puede necesitar manejo de errores si un atributo no existe
        System.out.println("  Resultado de la Predicción para el nuevo paciente: " + resultadoPrediccion);
    }
}