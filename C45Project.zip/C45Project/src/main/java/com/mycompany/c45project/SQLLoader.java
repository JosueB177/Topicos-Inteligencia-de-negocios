package com.mycompany.c45project;

import java.sql.*;
import java.util.*;

public class SQLLoader {
    private final String connectionUrl = "jdbc:sqlserver://localhost;instanceName=SQLEXPRESS;databaseName=prueba;encrypt=true;trustServerCertificate=true";
    private final String user = "usuario_c45";
    private final String password = "1234";

    // Cargar datos desde la tabla/vista
    public List<Map<String, String>> cargarDatos(String tabla) {
        List<Map<String, String>> datos = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(connectionUrl, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM " + tabla)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int numCols = metaData.getColumnCount();

            while (rs.next()) {
                Map<String, String> fila = new HashMap<>();
                for (int i = 1; i <= numCols; i++) {
                    String colName = metaData.getColumnName(i);
                    String val = rs.getString(i);
                    // No excluimos "Id" aquí porque la vista puede tener sus propios IDs
                    // que podrían ser útiles o no. La exclusión de atributos no predictivos
                    // se hará en obtenerAtributos o en la lógica principal.
                    fila.put(colName, val);
                }
                datos.add(fila);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error al cargar datos de la tabla '" + tabla + "': " + e.getMessage());
            e.printStackTrace();
        }
        return datos;
    }

    // Obtener solo los atributos útiles (sin la clase y sin columnas no deseadas)
    public List<String> obtenerAtributos(String tabla, String columnaClase, List<String> columnasAIgnorar) {
        List<String> atributos = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(connectionUrl, user, password);
             Statement stmt = conn.createStatement();
             // Usamos TOP 0 para obtener solo metadatos, más eficiente si la tabla es grande.
             // O TOP 1 si TOP 0 no es soportado o da problemas con algunos drivers/versiones.
             ResultSet rs = stmt.executeQuery("SELECT TOP 1 * FROM " + tabla)) { 

            ResultSetMetaData metaData = rs.getMetaData();
            int numCols = metaData.getColumnCount();

            for (int i = 1; i <= numCols; i++) {
                String colName = metaData.getColumnName(i);
                
                // Excluir la columna clase, la columna "Id" (si existiera con ese nombre exacto)
                // y cualquier otra columna especificada en columnasAIgnorar.
                // Hacemos la comparación insensible a mayúsculas/minúsculas.
                boolean ignorar = colName.equalsIgnoreCase(columnaClase) || 
                                  colName.equalsIgnoreCase("Id"); // Exclusión genérica de "Id"

                if (!ignorar && columnasAIgnorar != null) {
                    for (String colAIgnorar : columnasAIgnorar) {
                        if (colName.equalsIgnoreCase(colAIgnorar)) {
                            ignorar = true;
                            break;
                        }
                    }
                }
                
                if (!ignorar) {
                    atributos.add(colName);
                }
            }

        } catch (SQLException e) {
            System.err.println("❌ Error al obtener atributos de la tabla '" + tabla + "': " + e.getMessage());
            e.printStackTrace();
        }
        return atributos;
    }

    // Sobrecarga del método para mantener compatibilidad si no se pasan columnas a ignorar
    public List<String> obtenerAtributos(String tabla, String columnaClase) {
        // Por defecto, solo ignoramos "Id" y la columna clase.
        // Para el caso de VIH, es mejor usar la versión que especifica columnas a ignorar.
        return obtenerAtributos(tabla, columnaClase, Arrays.asList("Id")); 
    }
}
